# Operating principles, preconditions, and project layout (every phase)

Shared by every `event-modeling-*` skill. Read this before doing any work in any phase — it's
the discipline and mechanics that don't change no matter which phase you're facilitating.
`methodology.md` (the 7 steps + 4 patterns) and `em-dsl.md` (DSL syntax and validation rules) in
this same directory are the other two shared references; read them too before doing real work —
they, together with this doc, are the source of truth every phase skill builds on. Templates
live in `templates/`, a sibling of this `reference/` directory. References to `docs/*.md`
throughout these skills mean the
[em repository's docs](https://github.com/milehimikey/em/tree/main/docs) — they are not
vendored alongside these skills, with one exception: the frontmatter schema doc is vendored
right here as `reference/slice-doc-schema.md` (kept in sync with the em repo's
`docs/slice-doc-schema.md` by `em`'s own `docs:generate`/`docs:check`), so every
`slice-doc-schema.md` reference elsewhere in this bundle points there instead of at `docs/`.

## Operating principles

- **Socratic, one question at a time.** Ask focused questions; use `AskUserQuestion` for tight
  multiple-choice decisions. Never assume a domain fact — extract it. Prefer "who/why/what-if/
  what-must-always-be-true/how-do-you-know" over yes-no.
- **Don't guess — park it.** Unresolved items go into the Open Questions list in
  `.event-modeling.md`, not into invented model content. Note the source, blocker, and revisit
  date when known — cheap now, useful when you come back to it.
- **Happy path first; branches belong to slicing.** Steps 1-7 build the **happy-path spine**.
  Alternate, unhappy, and exception-path events (rejections, removals, cancellations,
  expirations, declines) are **not** enumerated as a separate discover/model task — they
  surface during the `slice` phase as each slice's alternate/error flows and rule-boundary
  scenarios, and any new branch events get added to the `.em` then. Never list "draft the
  branch events" as a discover/model to-do or ask the user to do it before slicing.
- **Reflect and re-render.** After each meaningful increment, update the `.em` file, re-render,
  and show the user what changed. Encourage running the live view (`watch`) so a team can follow.
- **Keep the `.em` structural; put depth in `note` docs.** The diagram holds flow; invariants,
  fields, and scenarios live in `slices/*.md` linked via `note "slices/<name>.md"`.
- **Headless/API models still use `ui`.** If the system is headless (clients call an API, not
  screens), declare a persona per external caller/role (e.g. `IntegratorAPI`) and treat its `ui`
  boxes as API calls, not screens: writes are `ui → command → event` and reads are
  `read model → ui`, exactly like any other State Change/State View slice — no separate trigger
  slice. `translation` stays reserved for genuine reactions and real external-system boundaries,
  not a synchronous request/response call. Internal-only commands/views with no public route carry
  no `ui` at all — they follow the ordinary Automation pattern instead. **Repeat read models**
  across slices so the timeline flows left-to-right — put each repeat **right after the event that feeds it**, sourcing
  only that one adjacent event, so every arrow is short (a read model far from its source events
  draws a long arrow whose head lands columns away, making the *write* slice read as dangling —
  keep a sub-flow that detours into another context together, not parked at the end of the model).
  Declare every instance after the first with
  **`view X again from "..."`** — `again` instances are exempt from the duplicate-name warning even
  when referenced, and each reference resolves to the right instance. A reaction's command is
  wired by same-slice presence, exactly like `ui → command` — no positional/adjacency rule to get
  right (see `em-dsl.md`).
  See `methodology.md` (State View) and `em-dsl.md`.
- **Never connect two instances of one read model.** The repeat is a timeline device, not a flow:
  continuity is implied by the shared name, and the events arriving at each instance are what show
  it changing. An arrow between instances says the read model feeds itself, and is an error.
- **Every slice is a COMPLETE pattern, never a half-slice.** A State Change is
  `ui → command → event`; a State View is `event → read model → ui` (or `→ reaction`). So: a
  command needs something that **triggers** it (the `ui` it's issued from, or the reaction that
  triggers it, also in this slice), its event needs a **reader**, and that read model needs a
  **consumer** of its own. A command nothing points at is a write nobody can start; a reaction
  that triggers no command is a decision the system never acts on; an event nothing projects is
  a write nobody can see; a read model nothing displays is information dropped on the floor.
  Write the whole chain together rather than sweeping up dangling ends later. Reactions don't
  count as readers of *events* — they read views. **Every instance** of a repeated read model
  needs its own consumer: if you repeat a view next to an event just to keep the arrow short,
  bring its screen along, or don't add the instance.
- **Only six connections are legal:** `ui → command`, `command → event`, `event → read model`,
  `read model → ui`, `read model → reaction`, `reaction → command`. Reaching for anything else —
  above all `command → read model` (the CQRS violation) or `read model → command` — means the model
  is missing an **element**, not an arrow.
- **Validate continuously.** Run `em validate` and fix errors/warnings as you go (see DSL ref).
- **Save state at the end of every session** so work resumes cleanly. Also log a Usage log
  line: `em state log-usage <model>.em --phases <phase1,phase2,...>` computes and dedupes the
  diagnostic *categories* that fired for you and appends the canonically-formatted line — never
  hand-run `em validate --json` and format the line yourself. This is the team's only usage
  signal today (`docs/usage-data.md`) — keep it cheap and habitual, not a task to skip.

## Write scope and evidence (MIL-236)

These bind every design session — `discover`, `model`, `slice` — whichever skill runs it,
including sessions started from bare `/event-modeling`.

- **Write scope: one model directory.** The session is bound to the model directory it started
  in: `dirname(<model>.em)`, which holds `slices/`, `model-versions/`, `conformance/`,
  `contracts/`, `.event-modeling.md` and `README.md`. Never write under another model's
  directory or to another model's contract file (`<model dir>/contracts/<model key>.tsp`). When
  you need a neighbour, read only its public surface, read-only: the elements with
  `public: true` in `em export <neighbour>.em`, or its committed contract file. Never open the
  neighbour's slice docs or state file.
- **Seam change request instead of a cross-model edit.** When resolving an open question needs
  another model's `public` element changed (a field added, renamed, retyped; an element made
  `public`), record it in THIS model's `.event-modeling.md` `## Decisions log` as one dated
  bullet, exactly this shape (`em changelog` reads only dated bullets):

  ```
  - YYYY-MM-DD: seam change request → <producerKey>:<kind>.<slug> — <what> — <why>
  ```

  `<producerKey>:<kind>.<slug>` is the same ref a `consumes` clause uses (`kind` is `event` or
  `view`; write `command` for a public command). Leave the open question open with
  `blocked on: <producerKey> owners (seam change request YYYY-MM-DD)`, and tell the user to take
  the request to the producer's owners. Never edit the other side.
- **Out of scope during design — never write these:**
  - generated contract artifacts: `contracts/*.tsp`, any OpenAPI or JSON-schema output;
  - SDD/spec artifacts: `specs/`, `.specify/` (read `.specify/memory/constitution.md` when a
    slice needs the house rules; never write it);
  - implementation source: `src/`, and any path under the model's `Code roots:` bullet;
  - `plugin/` (the generated skill plugin);
  - a draft slice doc's `version:` (see the version rule below).

  One exception, and only this one: when the session marks an element `public` (or changes a
  field of a `public` element), run `em api generate <model>.em` before handing slices to
  ratification. The API-first gate (`em validate --slice-ready`) refuses a public-touching
  slice whose contract is missing or stale, so the regenerated `contracts/<model key>.tsp` is
  committed with the model edit. Never hand-edit it.
- **Evidence rule.** The `.em` model and the slice docs are the evidence for every modeling
  decision. Never open implementation source, generated contracts, or `specs/` to settle a
  modeling question; ask the user. Code is consulted only in `extract`
  (`event-modeling-discover`) and `conform` (`event-modeling-conform`), where reading it is the
  point.
- **Version rule: never bump a draft's `version:` on edit.** A `draft`/`reviewed` doc is edited
  in place. Check the release state with `em status <model>.em --json`: the model is
  **pre-release** when its `modelVersion` entry has `design: null` and
  `slices.byStatus.shipped === 0`. Pre-release: never run `em slice revise`; edit
  `draft`/`reviewed` docs in place and leave `version:` as it is. A pre-release doc that is
  already ratified (`ready-to-implement` with `ratifiedBy`) carries a human sign-off: STOP,
  record the needed change as an open question, and let the ratifier decide. Released (either
  condition false): changing a shipped or ratified doc goes through `em slice revise`, which
  opens the next version as a `draft` (see `event-modeling-design`).
- **Pre-commit check (STOP on any finding).** Stage the session's files, then run both:
  1. `em system scope --staged` from the repository root. Any `seam-crossing` error → STOP:
     unstage the other model's files and record a seam change request instead.
  2. `git diff --cached --name-only`. Any path outside the bound model directory, or any
     out-of-scope path above (`contracts/*.tsp` except the regenerated exception, OpenAPI /
     JSON-schema output, `specs/`, `.specify/`, `src/`, code roots, `plugin/`), or a draft
     doc whose `version:` line changed (`git diff --cached -- <doc>`) → STOP: unstage it and
     tell the user what was touched and why it is out of scope.

## Preconditions (run first)

1. Check the tool: `em --version`. If missing, tell the user to run `npm i -g @milehimikey/em`
   and stop until installed.
2. Check this vendored skill bundle's own currency (MIL-219): read this file's `em-version:`
   frontmatter stamp (or any sibling skill's SKILL.md — they're stamped together) and compare it
   to `em --version` from step 1. **If the installed em is ahead by a minor version or more
   (1.9.x → 1.11.x, or any major bump), STOP** — don't proceed with discover/model/slice/
   implement/conform/review work on this stamp. Tell the user the vendored bundle is stale and to
   run `em skill sync` (refresh the bundle only) or `em upgrade` (the bundle plus the model
   repo's other mechanical migrations, docs/upgrading.md) before continuing. A patch-only gap
   (1.11.2 → 1.11.4) is never worth stopping over — proceed normally. This matters because a
   stale bundle silently follows old rules: an agent reading superseded preconditions/gates
   can hand back work that looks right by last week's contract and wrong by this week's.
3. Locate the model. Look for an existing `<dir>/.event-modeling.md` and `*.em` in the working
   directory, or — for a multi-model project laid out per the convention below — one level down
   inside a `models/` subfolder (each model gets its own `models/<slug>/` directory; check each
   candidate for its own `.event-modeling.md`/`*.em` pair). If found, run `em state read <dir>`
   to read the state file's mechanical fields (model path, phase, step, last updated, last
   conformance, last review) as JSON — don't parse the bullets by hand. If not, and the phase
   needs one, ask the user for the model name and where to create it (a lone model goes at the
   project root; one of several goes under `models/`, per "Multi-model projects" below).
4. If you're not sure which phase applies, or the user gave no phase, use `em state read <dir>`'s
   `phase`/`step` to resume the recorded phase/step — or invoke the `event-modeling` skill, which
   does exactly this and routes to the right skill. If no model exists, propose starting
   `discover` (greenfield, `event-modeling-discover`) or `extract` (modeling an existing system,
   also `event-modeling-discover`).
5. Populate the state file's Participants section at session start. For a live workshop, ask for
   a single human proxy to relay questions to the room, and attribute every answer/decision in
   the Decisions log to a named participant.

## Project layout these skills create

```
<model-name>/
  <model-name>.em          # the model (slice docs linked via note "...")
  <model-name>.svg         # render target for em watch
  README.md                # overview + slice index (from templates/model-readme.md)
  .event-modeling.md       # resumable state (from templates/state.md)
  slices/<slice-name>.md   # one rich slice doc per slice (from templates/slice.md)
  conformance/<date>-report.md
                           # conform-phase reports (from templates/conformance-report.md)
  <model-name>-asis.em     # conform-phase scratch model, regenerated per run — git-ignore this
```

When creating a new model, run `em scaffold <model-name>` — it creates `<model-name>/` and
writes all three starter files in one step (`<model-name>.em`, `README.md`,
`.event-modeling.md`), filling the Model Name/model-name placeholders and the state file's
mechanical fields (model path, `Current phase: discover`, `Current step: 1`, dates) for you, so
there's nothing left to hand-copy or fill in. Refuses if `<model-name>/` already exists; pass
`--force` to overwrite. You'll
usually replace the scaffolded `.em`'s content as the discovery conversation builds up the real
model — it starts out as the same starter model `em init` writes, titled from `<model-name>`.
`slices/*.md` and `conformance/` aren't part of `em scaffold`; they come from the `slice` and
`conform` phases (`event-modeling-design` and `event-modeling-conform`). The `conformance/`
directory and `<model-name>-asis.em` only appear once the `conform` phase runs; `em conform-scope
--seed-asis` creates `<model-name>-asis.em` and gitignores `*-asis.em` for you (see
`event-modeling-conform`'s `reference/conform.md`) — it's scratch, never committed.

### Multi-model projects

Slice docs resolve at a fixed path — `slices/<slug>.md`, sibling of the `.em` file that
declares the slice — with no model namespace anywhere, so **one directory per model** is the
whole guardrail against two models' slice names colliding. For more than one model, nest each
one's directory (the exact layout above) under a shared `models/` parent instead of scattering
them at the project root:

```
models/
  checkout/
    checkout.em
    slices/...
  fulfillment/
    fulfillment.em
    slices/...
```

Run `em scaffold <model-name> --under models` for each model — it creates `models/<slug>/`
directly rather than a two-step `cd models && em scaffold <model-name>`. See
[docs/cli.md, "Multi-model projects"](https://github.com/milehimikey/em/blob/main/docs/cli.md#multi-model-projects)
for the full rationale, and why slice keys stay unqualified (no `<model>/<slice>` prefix) —
directory isolation alone is sufficient. Two `.em` files sharing a directory with colliding
slice keys don't go undetected: `em status`/`em catalog`, the two commands that ever compile
more than one model in a run, raise a `cross-model-slice-doc-collision` warning naming both
files — treat that warning as a sign the models need separating, not a false positive.
